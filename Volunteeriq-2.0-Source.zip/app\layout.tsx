import type { Metadata } from "next";
import { Syne, IBM_Plex_Mono, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";

const syne = Syne({
  variable: "--font-syne",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

const ibmPlexMono = IBM_Plex_Mono({
  variable: "--font-ibm-plex-mono",
  subsets: ["latin"],
  weight: ["400", "500"],
});

const jakarta = Plus_Jakarta_Sans({
  variable: "--font-jakarta",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: "VolunteerIQ — Intelligent Volunteer Coordination",
  description:
    "AI-powered disaster relief coordination platform. Smart resource allocation for NGOs and volunteer networks across India.",
  keywords: ["volunteer", "coordination", "disaster relief", "NGO", "AI", "India", "earthquake", "cyclone", "flood"],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${syne.variable} ${ibmPlexMono.variable} ${jakarta.variable}`}
      suppressHydrationWarning
    >
      <body className="min-h-screen bg-bg1 text-text1 font-sans antialiased">
        {children}
      </body>
    </html>
  );
}
